% finite diference method
function U=MDF(f,u,h)
% data
N = 1/h -1;
[x,y] = meshgrid(0:h:1,0:h:1);
% matrices
E = ones(N,1); I = speye(N); % ones and identity matrix
A1 = spdiags([-E 2*E -E],-1:1,N,N); % 1D Poisson matrix
A = kron(A1,I)/h^2 + kron(I,A1)/h^2; % 2D Poisson matrix
% right-hand side
F = f(x(2:end-1,2:end-1),y(2:end-1,2:end-1));
for i=1:N
    F(1,i) = F(1,i) + u(x(1,i+1),0)/h^2; % first line of F
    F(N,i) = F(N,i) + u(x(1,i+1),1)/h^2; % last line of F
    F(i,1) = F(i,1) + u(0,y(i+1,1))/h^2; % first column of F
    F(i,N) = F(i,N) + u(1,y(i+1,1))/h^2; % last column of F
end
F = reshape(F,N*N,1);
% numerical solution
U = A\F; U = reshape(U,N,N);
% boundary
b1 = zeros(N+2,1); b2 = zeros(N+2,1); b3 = zeros(1,N); b4 = zeros(1,N);
for i=1:(N+2)
    b1(i)= u(0,y(i,1)); %boundary for x=0 with corner
    b2(i)= u(1,y(i,1)); %boundary for x=1 with corner
end
for i=2:(N+1)
    b3(i-1)= u(x(1,i),0); %boundary for y=0 without corner
    b4(i-1)= u(x(1,i),1); %boundary for y=1 without corner
end
% solution
U = [b1, [b3; U; b4], b2];
end