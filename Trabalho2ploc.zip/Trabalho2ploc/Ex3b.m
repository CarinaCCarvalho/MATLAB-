clc; clear;
     
n=10;
m=;
I=eye(n^2);
A=AdjG(n);

% gerar pontos aleatorios
pontos=randperm(n^2,m)


% construir a matriz D
D = zeros(2*n*n+2);
%ciclo para escrever a matriz D
for i=1:(n*n)
        for j=(n*n+1):(2*n*n) 
                D(i,j)=I(i,j-n*n); % matriz I
        end
end
for i=(n*n+1):(2*n*n) 
    for j=1:(n*n)
        D(i,j)=A(i-n*n,j); % matriz A
    end
end


% para escrever o vetor s
for u=1:m
    for v=1:(n^2)
        if (pontos(u)==v)
            D(2*n^2+1,v)=1;
        end
    end
end

% para escrever o vetor t 
front=FrontG(n)

for u=(n^2+1):(2*n^2)
        for v=1:length(front)
        if (u==front(v)+n^2)
            D(u,2*n^2+2)=1;
        end
    end
end


C=D;
s=2*n^2+1;
t=2*n^2+2;

L=length(D); % tamanho de D é L


%Algoritmo de Ford Fulkerson
X=zeros(L);
B=D;
terminado=false;

while terminado ~= true  % enquanto nao terminado
v=BFS(B,s);

if v(t)==0
    terminado=true;
else cmc=caminho(s,t,v); 
    P=length(cmc); % tamanho do cmc é P
    
    % Para cada aresta do caminho procurar a capacidade de incremento
    incremento=max(max(C));
    for j=2:P
        % Calcular o minimo δ das capacidades de incremento
        if C(cmc(j),cmc(j-1)) > X(cmc(j),cmc(j-1)) %Teorema
            incremento=min(incremento, C(cmc(j), cmc(j-1)) - X(cmc(j),cmc(j-1)));
        else
            incremento=min(incremento, C(cmc(j),cmc(j-1)));
        end
    end

    % Adicionar δ em X a todas as entradas que correspondem a arestas do caminho
    for j=2:P
        X(cmc(j),cmc(j-1))= X(cmc(j),cmc(j-1)) + incremento;
        X(cmc(j-1),cmc(j))= X(cmc(j-1),cmc(j)) - incremento;
    end

    % Alterar B 
    for j=2:P
        if C(cmc(j),cmc(j-1)) > X(cmc(j),cmc(j-1))
            B(cmc(j),cmc(j-1))=1;
        else
            B(cmc(j),cmc(j-1))=0;
        end
        if X(cmc(j),cmc(j-1)) > 0
        B(cmc(j-1),cmc(j))=1;
        end
    end
end
end


R=length(X); % tamanho de X é R
% escrever fluxo maximo
g=0;
for i=1:R
    g=g+X(i,t);
end
g

% funcao para os pontos da fronteira (1ª e ultima linhas e 1ª e ultima colunas)
function front=FrontG(n)
% matriz com os vertices de 1 a n^2
vertices=zeros(n);
for j=1:n 
    vertices(1,j)=j; % linha 1 
    for i=2:n % a partir da linha 2
        vertices(i,j)= vertices(i-1,j)+n;
    end
end

f=1;
% primeira linha
for j=1:n
    front(f)=j;
    f=f+1;
end
% primeira coluna
for i=2:(n-1)
    front(f)=vertices(i,1);
    f=f+1;
end
% ultima coluna
for i=2:(n-1)
    front(f)=vertices(i,n);
    f=f+1;
end
% ultima linha
for j=1:n
    front(f)=vertices(n,j);
    f=f+1;
end
end


%funcao do caminho mais curto
function cmc=caminho(s,t,v) %caminho de s para t atraves de v

cmc(1)=t; 
j=2; %em j=1 é s
while cmc(j-1) ~= s %enquanto o caminho nao for s
    cmc(j)=v(cmc(j-1)); %t ←v(t)←v(v(t))←... ←v(v(..(v(t))))=s
    j=j+1;
end
end

% funcao da matriz de adjacencias da grelha
function adj=AdjG(n)

% matriz de adjacencia      
diagVec1 = repmat([ones(n-1, 1); 0], n, 1);  % faz o primeiro vetor diagonal
diagVec1 = diagVec1(1:end-1);                % remove o ultimo valor

diagVec2 = ones(n*(n-1), 1);                 % faz o segundo vetor diagonal
                                             
adj = diag(diagVec1,1)+diag(diagVec2,n);   % adicionar as diagonais a uma matriz de zeros
adj = adj+adj.';             % adicionar a matriz à sua transposta para a tornar simetrica
end
