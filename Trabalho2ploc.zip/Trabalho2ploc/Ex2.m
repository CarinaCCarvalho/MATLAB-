clc; clear;

%Input: 
% 	B - matriz de adjacência do grafo residual
% 	X - variável do fluxo
% 	V - numero de vertices

%Inicialização:

C=[]; % C - matriz das capacidades 
A=[]; % A - matriz de adjacência de um grafo

n=size(A,1);
s= ; % s - vértice inicial
t= ; % t - vértice final

L=length(A); % tamanho de A é L

% Algoritmo de Ford Fulkerson
X=zeros(L);
B=A;
terminado=false;

while terminado ~= true  % enquanto nao terminado
v=BFS(B,s);

if v(t)==0
    terminado=true;
else
    cmc=caminho(s,t,v); 
    P=length(cmc); % tamanho do cmc é P
    
    %Para cada aresta do caminho procurar a capacidade de incremento
    incremento=max(max(C));
    for j=2:P
        %Calcular o minimo δ das capacidades de incremento
        if C(cmc(j),cmc(j-1)) > X(cmc(j),cmc(j-1)) %Teorema
            incremento=min(incremento, C(cmc(j), cmc(j-1)) - X(cmc(j),cmc(j-1)));
        else
            incremento=min(incremento, C(cmc(j),cmc(j-1)));
        end
    end

    %Adicionar δ em X a todas as entradas que correspondem a arestas do caminho
    for j=2:P
        X(cmc(j),cmc(j-1))= X(cmc(j),cmc(j-1)) + incremento;
        X(cmc(j-1),cmc(j))= X(cmc(j-1),cmc(j)) - incremento;
    end

    %Alterar B 
    for j=2:P
        if C(cmc(j),cmc(j-1)) > X(cmc(j),cmc(j-1))
            B(cmc(j),cmc(j-1))=1;
        else
            B(cmc(j),cmc(j-1))=0;
        end
        if X(cmc(j),cmc(j-1)) > 0
        B(cmc(j-1),cmc(j))=1;
        end
    end
end
end


R=length(X); %tamanho de X é R
%escrever fluxo maximo
g=0;
for i=1:R
    g=g+X(i,t);
end
g

%funcao do caminho mais curto
function cmc=caminho(s,t,v) %caminho de s para t atraves de v

cmc(1)=t;
j=2; %em j=1 é s
while cmc(j-1) ~= s %enquanto o caminho nao for s
    cmc(j)=v(cmc(j-1)); %t ←v(t)←v(v(t))←... ←v(v(..(v(t))))=s
    j=j+1;
end
end