close all; clc; clear; 

% Definicao da malha
Nx = 40; % nr pontos em x (tempo)
Ny = 40; % nr pontos em y (distancia)
% Dominio Lx x Ly
Lx= 10;
Ly= 10;

dx = Lx/(Nx-1); % Espaçamento em x
dy = Ly/(Ny-1); % Espaçamento em y
x=(0:dx:Lx)'; 
y=(0:dy:Ly)';

% Tempo (t)
T= 1; 
M= 2000; % Nr de pontos no tempo
dt= T/M; % Espacamento no tempo
t=(0:dt:T);

% Coeficientes
Eps = 0.01; % Coef. difusao
a1 = 0.05; % Velocidades
a2= 0.08;

% U-Concentracao da distribuicao de fluido
U=zeros(Nx,Ny); % Alocar espaco para concentracao

% Condicoes iniciais- metodo centrado
for i=1:Nx
    for j=1:Ny
        U(i,j)=x(i)*(Lx-x(i))*y(j)*(Ly-y(j));
    end
end

% MDF-Euler Explicito
for m=2:M
    for i=2:Nx-1 
        for j=2:Ny-1
            U(i,j) = U(i,j)-(1/2*dt*a1)*(U(i+1,j)-U(i-1,j))/dx-(1/2*dt*a2)*(U(i,j+1)-U(i,j-1))/dy + (Eps*dt)*((U(i+1,j)-2*U(i)+U(i-1,j))/dx^2+(U(i,j+1)-2*U(j)+U(i,j+1))/dy^2);
        end
    end
end

plot(U),grid
figure
surf(U)
[t,x] = meshgrid(t,x);
surf(U)