% Exercício 2a)

f=@(x1,x2) (4*(x1.^2))+(3*(x2.^2))-(6*x1)-(4*x2)+(2*x1.*x2)+3; % funcao objetivo
g=@(x1) 1-3*x1; % x_2 através da 1º restrição
h=@(x1) 1-x1; % x_2 através da 2º restrição
x1=linspace(0,1);
[X1,X2]=meshgrid(x1,x1);
Z=f(X1,X2);
contour(X1,X2,Z,150); % curvas de nível
hold on
fplot(g,[0 1/3],'r')
hold on
fplot(h,[0 1],'g')
hold off