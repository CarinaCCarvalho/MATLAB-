% Exercício 3

f=@(x1,x2) (4*(x1.^2))+(3*(x2.^2))-(6*x1)-(4*x2)+(2*x1.*x2)+3; % funcao objetivo
g=@(x1) 1-3*x1; % x_2 através da 1º restrição
h=@(x1) 1-x1; % x_2 através da 2º restrição
i=@(x1) 1-x1; 
j=@(x1) (1/8)*x1+(3/8); 
x1=linspace(0,1);
[X1,X2]=meshgrid(x1,x1);
Z=f(X1,X2);
contour(X1,X2,Z,150); % curvas de nível
hold on
fplot(g,[0 1/3],'r')
hold on
fplot(h,[0 1],'g')
hold on
fplot(i,[5/9 3/5],'m') % intervalo de x1 para a funcao i
hold on
fplot(j,[0 5/9],'b') % intervalo de x1 para a funcao j
hold off


