%Exercicio 5

f=@(r) sqrt((5*(r.^2)-(18*r)+17)/4);
[a,b]=fplot(f,[9/5 17/9]);
g=@(r) sqrt((11*(r.^2)-(36*r)+34)/25);
[c,d]=fplot(g,[17/9 29/8]);
h=@(r) sqrt(3*(r.^2)-(20*r)+35);
[e,f]=fplot(h,[29/8 4]);
p=linspace(0.3,1);
t=((sqrt(411)/(4*sqrt(2)))*p)+0.25; % rácio de sharpe e rf
hold on
plot(b,a);
plot(d,c);
plot(p,t);
plot((sqrt(822)/61), (118/61), '.', 'MarkerSize',12); % risco e retorno
hold off