close all; clc; clear; 

% Funcao a aproximar
f=@(x) (x-1).^2;
a=0; b=3;
xx=a:0.01:b;

% Funcao objetivo 
% u=[x,y]=[u,v]=[u(1),u(2)]
s1=@(t,u) (u(2)-f(a))*(t-a)/(u(1)-a)+f(a);
s2=@(t,u) (f(b)-u(2))*(t-u(1))/(b-u(1))+u(2);

f1=@(t,u) (f(t)-s1(t,u)).^2;
f2=@(t,u) (f(t)-s2(t,u)).^2;

% Integral do^2 da diferença entre f e g 
fObjetivo = @(x) integral(@(t) f1(t,x),a,x(1)) + integral(@(t) f2(t,x),x(1),b);
x0=[a+(b-a)/3,0];

% Funcao Dual
lambda=-2:0.1:2;
Lagrangeano= @(x,lambda) fObjetivo(x) - lambda*(x(2)-f(x(1)));
Ldual= @(lambda) LagAux( lambda,Lagrangeano,x0);
LdualVetor= zeros(1,length(lambda));

for i=1:length(lambda)
    LdualVetor(i)=Ldual(lambda(i));
end
indexDual= LdualVetor > -10^6;

% Maximo do vetor LdualVetor
max_val = max(LdualVetor)

function optVal = LagAux(lambda,Lagrangeano,x0)
[~,optVal]=fminsearch(@(x) Lagrangeano(x,lambda),x0);
end
