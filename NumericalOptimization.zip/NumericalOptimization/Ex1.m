close all; clc; clear; 

% Funcao a aproximar
f=@(x) (x-1).^2;
a=0; b=3;
xx=a:0.1:b;
plot(xx,f(xx))

% Funcao objetivo 
% u=[x,y]=[u,v]=[u(1),u(2)]
s1=@(t,u) (u(2)-f(a))*(t-a)/(u(1)-a)+f(a);
s2=@(t,u) (f(b)-u(2))*(t-u(1))/(b-u(1))+u(2);

f1=@(t,u) (f(t)-s1(t,u)).^2;
f2=@(t,u) (f(t)-s2(t,u)).^2;

hold on
plot([a 1.2], [f(a) -0.25], [1.2 b], [-0.25 f(b)])
hold off