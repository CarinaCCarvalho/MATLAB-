close all; clc; clear; 

% Funcao a aproximar
f=@(x) (x-1).^2;
a=0; b=3;
xx=a:0.1:b;
plot(xx,f(xx))
hold on

% Funcao objetivo 
% u=[x,y]=[u,v]=[u(1),u(2)]
s1=@(t,u) (u(2)-f(a))*(t-a)/(u(1)-a)+f(a);
s2=@(t,u) (f(b)-u(2))*(t-u(1))/(b-u(1))+u(2);

f1=@(t,u) (f(t)-s1(t,u)).^2;
f2=@(t,u) (f(t)-s2(t,u)).^2;

% Integral do^2 da diferença entre f e g 
fObjetivo = @(x) integral(@(t) f1(t,x),a,x(1)) + integral(@(t) f2(t,x),x(1),b);
x0=[a+(b-a)/3,0]
[xOpt1,fOpt1,exitFlag,output]=fminsearch(fObjetivo,x0) % Metodo Nelder-Mead
[xOpt2,fOpt2,exitFlag,output]=fminunc(fObjetivo,x0) % Metodo Quasi-Newton

hold on
plot([a xOpt1(1)], [f(a) xOpt1(2)], [xOpt1(1) b], [xOpt1(2) f(b)])
hold off
