clear all
x=[-3.0000 -2.8776 -2.7551 -2.6327 -2.5102 -2.3878 -2.2653 -2.1429 -2.0204 -1.8980 -1.7755 -1.6531 -1.5306 -1.4082 -1.2857 -1.1633 -1.0408 -0.9184 -0.7959 -0.6735 -0.5510 -0.4286 -0.3061 -0.1837 -0.0612 0.0612 0.1837 0.3061 0.4286 0.5510 0.6735 0.7959 0.9184 1.0408 1.1633 1.2857 1.4082 1.5306 1.6531 1.7755 1.8980 2.0204 2.1429 2.2653 2.3878 2.5102 2.6327 2.7551 2.8776 3.0000]';
y=[-23.9998 -17.2839 6.5866 -5.9081 -1.6245 -0.6931 -1.5533 24.0652 10.2800 1.7739 9.9238 0.9933 24.3812 0.6150 1.6265 17.7044 -0.2148 17.0323 -1.1572 0.2312 -0.6352 13.8776 25.8494 0.1671 1.9260 22.7508 1.4319 17.8424 4.2187 5.0428 3.5174 4.6833 5.5255 4.7702 6.5430 5.5926 4.8141 4.6479 8.7106 2.5810 2.4033 2.3184 1.1010 2.6905 4.6376 7.2084 30.7026 14.1446 22.5372 42.5306]';
d=8;
n=50;

% ajustar uma reta pelo MMQ
for i = 1:n
    for j= 1:d+1, 
        X(i,1)= 1; %primeira coluna
        X(i,j)=x(i)^(j-1); %ultima linha
    end
end


%Resolver o sistema Xa=y pelo MMQ é equivalente a a=X:y
a=X\y;

I=eye(n); %matriz Identidade

%matriz X
for i = 1:n;
    for j= 1:d+1;
        X(i,j)=x(i)^(j-1); %ultima linha
    end
    X(i,1)= 1; %primeira coluna
end


%ciclo para escrever a matriz A
for i=1:n;
    for j=1:(d+1);
        A(i,j)= X(i,j); %matriz X
    end
        for j=(d+2):(n+d+1); %matriz -I
                A(i,j)=-I(i,j-(d+1));
        end
end
for i=(n+1):(2*n); %matriz -X
    for j=1:(d+1);
        A(i,j)=-X(i-n,j);
    end
        for j=(d+2):(n+d+1);%matriz -I
            A(i,j)=-I(i-n,j-(d+1));
        end
end

%matriz B
for j=1;
    for i=1:n;
    b(i,1)=y(i,1); %vetor y
    end
    for i=(n+1):2*n;
            b(i,1)=-y(i-n,j); %vetor -y
    end
end

%funcao objetivo
%vetor 
for i=1;
    for j=1:(d+1);
    z(i,j)=0;
    end
    for j=(d+2):(d+1+n);
            z(i,j)=1;
    end
end


%calculo matriz T
T = linprog(z,A,b);

%vetor T_t
for j=1;
    for i=1:(d+1);
    h(i,j)=T(i,j);
    end
end


%calcular erros
mmq=abs(X*a-y)'

pl=abs(X*h-y)'


hold on;
plot(x,y,'ok');
plot(x,X*a,'blue');
plot(x,X*h,'green');
hold off;