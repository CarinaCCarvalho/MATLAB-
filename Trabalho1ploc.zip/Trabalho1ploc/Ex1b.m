clear all
%vetores dados
y=[]';
x=[]';
%matriz Identidade 
I=eye(n); %matriz Identidade

%matriz X
for i = 1:n;
    for j= 1:d+1;
        X(i,j)=x(i)^(j-1); %ultima linha
    end
    X(i,1)= 1; %primeira coluna
end

%ciclo para escrever a matriz A
for i=1:n;
    for j=1:(d+1);
        A(i,j)= X(i,j); %matriz X
    end
        for j=(d+2):(n+d+1); %matriz -I
                A(i,j)=-I(i,j-(d+1));
        end
end
for i=(n+1):(2*n); %matriz -X
    for j=1:(d+1);
        A(i,j)=-X(i-n,j);
    end
        for j=(d+2):(n+d+1);%matriz -I
            A(i,j)=-I(i-n,j-(d+1));
        end
end

%matriz B
for j=1;
    for i=1:n;
    b(i,1)=y(i,1); %vetor y
    end
    for i=(n+1):2*n;
            b(i,1)=-y(i-n,j); %vetor -y
    end
end

%funcao objetivo
%vetor 
for i=1;
    for j=1:(d+1);
    z(i,j)=0;
    end
    for j=(d+2):(d+1+n);
            z(i,j)=1;
    end
end


%calculo matriz T
T = linprog(z,A,b);
T

