clear all
% dados 
x=[-3.0000 -2.8776 -2.7551 -2.6327 -2.5102 -2.3878 -2.2653 -2.1429 -2.0204 -1.8980 -1.7755 -1.6531 -1.5306 -1.4082 -1.2857 -1.1633 -1.0408 -0.9184 -0.7959 -0.6735 -0.5510 -0.4286 -0.3061 -0.1837 -0.0612 0.0612 0.1837 0.3061 0.4286 0.5510 0.6735 0.7959 0.9184 1.0408 1.1633 1.2857 1.4082 1.5306 1.6531 1.7755 1.8980 2.0204 2.1429 2.2653 2.3878 2.5102 2.6327 2.7551 2.8776 3.0000]'
y=[57.4199 44.9893 41.3377 24.8749 18.9345 21.7189 9.5733 17.8637 1.9198 -2.4792 -1.2989 -4.0373 -6.1774 16.1524 -4.1148 -2.7157 -3.3820 11.4661 -0.6835 0.1161 24.2745 7.5092 1.4589 3.0585 1.7877 2.8133 2.5308 1.8850 1.0740 0.2643 -0.5376 0.3757 14.2650 1.2576 0.6675 -1.0279 19.9123 22.6256 0.9077 20.5421 4.6255 6.2190 8.1579 12.2423 17.0397 40.7503 32.4397 41.0877 65.7795 63.8443]'
d=10;
n=50;
% ajustar uma reta pelo MMQ
for i = 1:n
    for j= 1:d+1, 
        X(i,1)= 1; %primeira coluna
        X(i,j)=x(i)^(j-1); %ultima linha
    end
end


%Resolver o sistema Xa=y pelo MMQ é equivalente a a=X:y
a=X\y;

I=eye(n); %matriz Identidade

%matriz X
for i = 1:n;
    for j= 1:d+1;
        X(i,j)=x(i)^(j-1); %ultima linha
    end
    X(i,1)= 1; %primeira coluna
end


%ciclo para escrever a matriz A
for i=1:n;
    for j=1:(d+1);
        A(i,j)= X(i,j); %matriz X
    end
        for j=(d+2):(n+d+1); %matriz -I
                A(i,j)=-I(i,j-(d+1));
        end
end
for i=(n+1):(2*n); %matriz -X
    for j=1:(d+1);
        A(i,j)=-X(i-n,j);
    end
        for j=(d+2):(n+d+1);%matriz -I
            A(i,j)=-I(i-n,j-(d+1));
        end
end

%matriz B
for j=1;
    for i=1:n;
    b(i,1)=y(i,1); %vetor y
    end
    for i=(n+1):2*n;
            b(i,1)=-y(i-n,j); %vetor -y
    end
end

%funcao objetivo
%vetor 
for i=1;
    for j=1:(d+1);
    z(i,j)=0;
    end
    for j=(d+2):(d+1+n);
            z(i,j)=1;
    end
end


%calculo matriz T
T = linprog(z,A,b);

%vetor T_t
for j=1;
    for i=1:(d+1);
    h(i,j)=T(i,j);
    end
end


%calcular erros
mmq=abs(X*a-y)'

pl=abs(X*h-y)'

hold on;
plot(x,y,'ok');
plot(x,X*a,'blue');
plot(x,X*h,'green');
hold off;