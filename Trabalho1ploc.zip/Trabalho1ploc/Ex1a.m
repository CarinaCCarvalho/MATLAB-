clear all
%m=d+1
%ciclo para escrever a matriz X
for i = 1:n
    for j= 1:m,
        X(i,1)= 1; %primeira coluna
        X(1,j)= x(1)^(j-1); %segunda linha
        X(2,j)= x(2)^(j-1);

        X(n,m)=x(n)^(m-1); %ultima linha
    end
disp(n)
end
X

%vetor y dado
y=[]';

%Resolver o sistema Xa=y e equivalente a a=X:y
a=X\y;




