close all; clc; clear; 

%Condicoes iniciais
u0=0;
v0=1;
tspan=[0,30];

%Parametros
A=1;
B=1;

%Resolucao ODE
%y=(u,v)
F=@(t,y)[A+y(1)^2*y(2)-(B+1)*y(1); B*y(1)-y(1)^2*y(2)]

[t,y]=ode45(F,tspan,[u0,v0])

%Definir y
u=y(:,1)
v=y(:,2)

plot(t,u,t,v);

